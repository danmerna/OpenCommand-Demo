"use client";

import { useState, useCallback } from "react";
import TopBar from "@/components/TopBar";
import MorningBriefing from "@/components/MorningBriefing";
import SocraticEngine from "@/components/SocraticEngine";
import ExecutiveBoard from "@/components/ExecutiveBoard";
import AgentDetail from "@/components/AgentDetail";
import CommandPalette from "@/components/CommandPalette";

export type TabId = "briefing" | "socratic" | "board" | "agent";

export default function Home() {
  const [activeTab, setActiveTab] = useState<TabId>("briefing");
  const [transitioning, setTransitioning] = useState(false);
  const [displayedTab, setDisplayedTab] = useState<TabId>("briefing");
  const [direction, setDirection] = useState<"left" | "right">("right");

  const tabOrder: TabId[] = ["briefing", "socratic", "board", "agent"];

  const switchTab = useCallback(
    (newTab: TabId) => {
      if (newTab === activeTab || transitioning) return;
      const oldIndex = tabOrder.indexOf(activeTab);
      const newIndex = tabOrder.indexOf(newTab);
      setDirection(newIndex > oldIndex ? "right" : "left");
      setTransitioning(true);
      setActiveTab(newTab);

      setTimeout(() => {
        setDisplayedTab(newTab);
        window.scrollTo(0, 0);
        setTimeout(() => {
          setTransitioning(false);
        }, 250);
      }, 200);
    },
    [activeTab, transitioning]
  );

  const handleAction = useCallback((action: string) => {
    if (action === "approve-all") {
      window.dispatchEvent(new CustomEvent("approve-all"));
    }
  }, []);

  const exitTransform =
    direction === "right" ? "translateX(-30px)" : "translateX(30px)";
  const enterTransform =
    direction === "right" ? "translateX(30px)" : "translateX(-30px)";

  const isExiting = transitioning && displayedTab !== activeTab;
  const isEntering = transitioning && displayedTab === activeTab;

  const style: React.CSSProperties = isExiting
    ? {
        opacity: 0,
        transform: exitTransform,
        transition: "all 0.2s ease-in",
      }
    : isEntering
      ? {
          animation: `slideIn 0.25s ease-out`,
        }
      : {};

  return (
    <>
      <TopBar activeTab={activeTab} onTabChange={switchTab} />
      <div style={style}>
        {displayedTab === "briefing" && <MorningBriefing />}
        {displayedTab === "socratic" && <SocraticEngine />}
        {displayedTab === "board" && <ExecutiveBoard />}
        {displayedTab === "agent" && <AgentDetail />}
      </div>
      <div className="border-t border-border px-6 py-4 flex justify-between font-mono text-[11px] text-text3">
        <span>
          Demo preview for Johnson Tractor &middot; Data shown is illustrative
        </span>
        <span>opencommand.co</span>
      </div>
      <CommandPalette onNavigate={switchTab} onAction={handleAction} />
      <style jsx>{`
        @keyframes slideIn {
          from {
            opacity: 0;
            transform: ${enterTransform};
          }
          to {
            opacity: 1;
            transform: translateX(0);
          }
        }
      `}</style>
    </>
  );
}
