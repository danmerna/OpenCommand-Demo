import type { Metadata } from "next";
import { JetBrains_Mono, DM_Sans } from "next/font/google";
import "./globals.css";

const dmSans = DM_Sans({
  variable: "--font-dm-sans",
  subsets: ["latin"],
  weight: ["400", "500", "600", "700"],
});

const jetbrainsMono = JetBrains_Mono({
  variable: "--font-jetbrains-mono",
  subsets: ["latin"],
  weight: ["400", "500", "600", "700"],
});

export const metadata: Metadata = {
  title: "Good Morning, Taylor.",
  description:
    "4 overnight changes detected · 3 strategies ready for today.",
  openGraph: {
    title: "Good Morning, Taylor.",
    description:
      "4 overnight changes detected · 3 strategies ready for today. — Open Command",
    type: "website",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html
      lang="en"
      className={`${dmSans.variable} ${jetbrainsMono.variable}`}
    >
      <body style={{ fontFamily: "var(--font-dm-sans), sans-serif" }}>
        {children}
        <div className="scanline-overlay" />
      </body>
    </html>
  );
}
