"use client";

import { TabId } from "@/app/page";

const TABS: { id: TabId; label: string }[] = [
  { id: "briefing", label: "Morning Briefing" },
  { id: "socratic", label: "Socratic Engine" },
  { id: "board", label: "Executive Board" },
  { id: "agent", label: "Agent Detail" },
];

export default function TopBar({
  activeTab,
  onTabChange,
}: {
  activeTab: TabId;
  onTabChange: (tab: TabId) => void;
}) {
  return (
    <div className="border-b border-border sticky top-0 bg-bg z-[100]">
      <div className="px-6 pt-3 flex items-center gap-2.5">
        <span className="font-mono text-accent font-bold text-[15px]">
          &gt;_
        </span>
        <span className="font-mono font-semibold text-sm">OPEN COMMAND</span>
        <span className="text-text3 mx-0.5">|</span>
        <span className="text-text2 text-xs">Johnson Tractor</span>
      </div>
      <div className="flex gap-0 px-6 pt-2 overflow-x-auto">
        {TABS.map((tab) => (
          <button
            key={tab.id}
            onClick={() => onTabChange(tab.id)}
            className={`font-mono text-[11px] font-normal px-3.5 py-2 bg-transparent border-none cursor-pointer whitespace-nowrap border-b-2 transition-all duration-150 ${
              activeTab === tab.id
                ? "text-accent border-b-accent font-semibold"
                : "text-text3 border-b-transparent hover:text-text2"
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>
    </div>
  );
}
