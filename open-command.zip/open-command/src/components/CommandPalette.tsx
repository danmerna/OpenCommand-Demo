"use client";

import { useState, useEffect, useCallback, useRef } from "react";
import { TabId } from "@/app/page";

const COMMANDS = [
  { id: "briefing", label: "Morning Briefing", shortcut: "1", type: "view" as const },
  { id: "socratic", label: "Socratic Engine", shortcut: "2", type: "view" as const },
  { id: "board", label: "Executive Board", shortcut: "3", type: "view" as const },
  { id: "agent", label: "Agent Detail", shortcut: "4", type: "view" as const },
  { id: "approve-all", label: "Approve All Strategies", shortcut: "a", type: "action" as const },
];

export default function CommandPalette({
  onNavigate,
  onAction,
}: {
  onNavigate: (tab: TabId) => void;
  onAction: (action: string) => void;
}) {
  const [isOpen, setIsOpen] = useState(false);
  const [search, setSearch] = useState("");
  const [selectedIndex, setSelectedIndex] = useState(0);
  const inputRef = useRef<HTMLInputElement>(null);

  const filtered = COMMANDS.filter((cmd) =>
    cmd.label.toLowerCase().includes(search.toLowerCase())
  );

  const execute = useCallback(
    (cmd: (typeof COMMANDS)[number]) => {
      setIsOpen(false);
      setSearch("");
      if (cmd.type === "view") {
        onNavigate(cmd.id as TabId);
      } else {
        onAction(cmd.id);
      }
    },
    [onNavigate, onAction]
  );

  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key === "k") {
        e.preventDefault();
        setIsOpen((prev) => !prev);
        setSearch("");
        setSelectedIndex(0);
      }
      if (e.key === "Escape" && isOpen) {
        setIsOpen(false);
      }

      // Number shortcuts (only when not in an input)
      if (!isOpen && !(e.target instanceof HTMLInputElement || e.target instanceof HTMLTextAreaElement)) {
        if (e.key === "1") onNavigate("briefing");
        if (e.key === "2") onNavigate("socratic");
        if (e.key === "3") onNavigate("board");
        if (e.key === "4") onNavigate("agent");
        if (e.key === "a") onAction("approve-all");
      }
    };
    window.addEventListener("keydown", handler);
    return () => window.removeEventListener("keydown", handler);
  }, [isOpen, onNavigate, onAction]);

  useEffect(() => {
    if (isOpen) {
      setTimeout(() => inputRef.current?.focus(), 50);
    }
  }, [isOpen]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-[300] flex items-start justify-center pt-[20vh]">
      <div
        className="fixed inset-0 bg-black/60"
        onClick={() => setIsOpen(false)}
      />
      <div className="relative bg-surface border border-border rounded-xl w-full max-w-md mx-4 overflow-hidden shadow-2xl">
        <input
          ref={inputRef}
          type="text"
          value={search}
          onChange={(e) => {
            setSearch(e.target.value);
            setSelectedIndex(0);
          }}
          onKeyDown={(e) => {
            if (e.key === "ArrowDown")
              setSelectedIndex((i) => Math.min(i + 1, filtered.length - 1));
            if (e.key === "ArrowUp")
              setSelectedIndex((i) => Math.max(i - 1, 0));
            if (e.key === "Enter" && filtered[selectedIndex])
              execute(filtered[selectedIndex]);
          }}
          placeholder="Type a command..."
          className="w-full bg-transparent border-b border-border px-4 py-3 text-sm text-text font-mono outline-none"
        />
        <div className="max-h-[240px] overflow-y-auto py-1">
          {filtered.map((cmd, i) => (
            <button
              key={cmd.id}
              onClick={() => execute(cmd)}
              className={`w-full text-left px-4 py-2.5 flex items-center justify-between transition-colors ${
                i === selectedIndex
                  ? "bg-accent-dim text-accent"
                  : "text-text2 hover:bg-surface2"
              }`}
            >
              <span className="text-[13px]">{cmd.label}</span>
              <span className="font-mono text-[10px] text-text3 bg-surface3 rounded px-1.5 py-0.5">
                {cmd.shortcut}
              </span>
            </button>
          ))}
        </div>
        <div className="border-t border-border px-4 py-2 flex justify-between">
          <span className="font-mono text-[10px] text-text3">
            {"↑↓"} navigate &middot; {"⏎"} select &middot; esc close
          </span>
          <span className="font-mono text-[10px] text-text3">{"⌘K"}</span>
        </div>
      </div>
    </div>
  );
}
