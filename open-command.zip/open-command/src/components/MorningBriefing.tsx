"use client";

import { useState, useCallback, useEffect } from "react";
import { Card, Btn, SectionLabel } from "./shared";

type StrategyStatus = "active" | "approved" | "later";

interface Strategy {
  id: number;
  badges: { label: string; color: string }[];
  title: string;
  description: string;
  impacts: { label: string; value: string; color?: string }[];
}

const STRATEGIES: Strategy[] = [
  {
    id: 1,
    badges: [
      { label: "CMO", color: "var(--color-cmo)" },
      { label: "CTO", color: "var(--color-cto)" },
    ],
    title: "Respond to 3 overnight leads + deploy auto-reply across all locations",
    description:
      "Three buyers waiting. Draft personalized responses from each location with Calendly links. Simultaneously deploy a unified SMS auto-reply for all future TractorHouse leads.",
    impacts: [
      { label: "Pipeline at stake", value: "$487K (3 units)", color: "var(--color-accent)" },
      { label: "Tasks generated", value: "5 (3 emails, 1 Twilio, 1 Calendly)" },
      { label: "Autonomy", value: "Level 1 — drafts for review" },
    ],
  },
  {
    id: 2,
    badges: [
      { label: "CFO", color: "var(--color-cfo)" },
      { label: "CMO", color: "var(--color-cmo)" },
    ],
    title: "Counter Birkey's price drop on 4 competing units",
    description:
      "Birkey's undercut you overnight. Your Rochelle/Harvard units are most exposed. Recommend repricing 4 comparable units to market-match. At 17.2% used margin, you'd still clear $32K+ gross per unit.",
    impacts: [
      { label: "Price reduction", value: "-$8K-$14K per unit", color: "var(--color-crit)" },
      { label: "Margin impact", value: "Still $32K+ gross + $16.8K service", color: "var(--color-accent)" },
      { label: "Floor plan saved", value: "$17,200/mo if sold", color: "var(--color-accent)" },
    ],
  },
  {
    id: 3,
    badges: [
      { label: "CEO", color: "var(--color-ceo)" },
      { label: "CFO", color: "var(--color-cfo)" },
    ],
    title: "Accept the Case IH 7240 trade-in at $196K",
    description:
      "Used combines generate 2.6x more first-year value than new. The 7240 appraisal is 4.4% below market — strong margin. Plus the selling customer may be in-market for new.",
    impacts: [
      { label: "Acquisition cost", value: "$196K (4.4% below market)" },
      { label: "Est. first-year value", value: "$62K (margin + service)", color: "var(--color-accent)" },
      { label: "Cross-sell", value: "Seller may buy new unit", color: "var(--color-accent)" },
    ],
  },
];

const ALERTS = [
  {
    icon: "\ud83d\udd34",
    iconBg: "rgba(239,68,68,.1)",
    iconBorder: "var(--color-crit)",
    title: "3 TractorHouse inquiries overnight \u2014 no auto-reply active",
    desc: "Two for the 2023 Case IH 8250 at Janesville ($289K) and one for the 6150 at Rochelle ($198K). Sitting since 10:30 PM, 1:15 AM, and 3:42 AM.",
    source: "Source: Gmail \u00b7 TractorHouse lead notifications",
  },
  {
    icon: "\ud83d\udfe1",
    iconBg: "rgba(245,158,11,.1)",
    iconBorder: "var(--color-warn)",
    title: "Birkey\u2019s Farm Store dropped 4 combine prices by 5-8%",
    desc: "Birkey\u2019s (62 miles from Rochelle) repriced their 8250, two 7250s, and a 6150 yesterday evening. Your equivalent units are now 11.3% above theirs.",
    source: "Source: TractorHouse competitive scrape \u00b7 5:30 AM",
  },
  {
    icon: "\ud83d\udd35",
    iconBg: "rgba(59,130,246,.1)",
    iconBorder: "var(--color-info)",
    title: "Trade-in eval completed: 2018 Case IH 7240 appraised at $196K",
    desc: "Entered in Anvil Pro by Juda location at 4:12 PM. Iron Comps market: $205K. Your appraisal is 4.4% below market \u2014 strong buy.",
    source: "Source: Anvil Pro \u00b7 Iron Comps",
  },
  {
    icon: "\ud83d\udfe2",
    iconBg: "rgba(16,185,129,.1)",
    iconBorder: "var(--color-accent)",
    title: "Osseo location sold a 2022 Case IH 8250 yesterday \u2014 $312K",
    desc: "Closed in 34 days from first contact. Service contract attached ($18,200/yr). This was a featured TractorHouse listing.",
    source: "Source: Anvil Pro \u00b7 QuickBooks",
  },
];

function ConfettiParticle({ delay, left }: { delay: number; left: number }) {
  const colors = ["#10b981", "#34d399", "#f59e0b", "#3b82f6", "#a78bfa", "#f472b6"];
  const color = colors[Math.floor(Math.random() * colors.length)];
  return (
    <div
      className="fixed w-2 h-2 rounded-sm z-[200] pointer-events-none"
      style={{
        left: `${left}%`,
        top: -10,
        background: color,
        animation: `confetti-fall ${1.5 + Math.random()}s ease-in ${delay}ms forwards`,
      }}
    />
  );
}

export default function MorningBriefing() {
  const [statuses, setStatuses] = useState<Record<number, StrategyStatus>>({
    1: "active",
    2: "active",
    3: "active",
  });
  const [showConfetti, setShowConfetti] = useState(false);

  const approvedCount = Object.values(statuses).filter((s) => s === "approved").length;
  const activeCount = Object.values(statuses).filter((s) => s === "active").length;

  const approve = useCallback(
    (id: number) => {
      setStatuses((prev) => {
        const next = { ...prev, [id]: "approved" as StrategyStatus };
        const allApproved = Object.values(next).every((s) => s === "approved");
        if (allApproved) {
          setTimeout(() => setShowConfetti(true), 300);
        }
        return next;
      });
    },
    []
  );

  const later = useCallback((id: number) => {
    setStatuses((prev) => ({ ...prev, [id]: "later" as StrategyStatus }));
  }, []);

  const approveAll = useCallback(() => {
    const activeIds = STRATEGIES.filter((s) => statuses[s.id] === "active").map(
      (s) => s.id
    );
    activeIds.forEach((id, i) => {
      setTimeout(() => approve(id), i * 200);
    });
  }, [statuses, approve]);

  useEffect(() => {
    if (showConfetti) {
      const timer = setTimeout(() => setShowConfetti(false), 3000);
      return () => clearTimeout(timer);
    }
  }, [showConfetti]);

  const activeStrategies = STRATEGIES.filter((s) => statuses[s.id] === "active");
  const laterStrategies = STRATEGIES.filter((s) => statuses[s.id] === "later");
  const approvedStrategies = STRATEGIES.filter((s) => statuses[s.id] === "approved");

  return (
    <div className="max-w-[680px] mx-auto px-6 py-7">
      {showConfetti &&
        Array.from({ length: 30 }).map((_, i) => (
          <ConfettiParticle
            key={i}
            delay={Math.random() * 500}
            left={Math.random() * 100}
          />
        ))}

      <div className="text-center mb-7 pb-6 border-b border-border">
        <div className="text-[22px] font-semibold tracking-[-0.03em] mb-1.5">
          Good morning, Taylor.
        </div>
        <div className="font-mono text-xs text-text3">
          Tuesday, June 16, 2026 &middot; 6:47 AM CDT &middot; 4 overnight
          changes detected
        </div>
      </div>

      <SectionLabel>Overnight Changes</SectionLabel>

      {ALERTS.map((alert, i) => (
        <Card key={i} className="flex gap-3 items-start">
          <div
            className="w-[30px] h-[30px] rounded-lg flex items-center justify-center text-[13px] shrink-0"
            style={{
              background: alert.iconBg,
              border: `1px solid ${alert.iconBorder}`,
            }}
          >
            {alert.icon}
          </div>
          <div>
            <div className="text-[13px] font-semibold mb-0.5">{alert.title}</div>
            <div className="text-xs text-text2 leading-[1.5]">{alert.desc}</div>
            <div className="font-mono text-[10px] text-text3 mt-1">
              {alert.source}
            </div>
          </div>
        </Card>
      ))}

      <SectionLabel>Today&apos;s Strategy</SectionLabel>
      <div className="text-[13px] text-text2 mb-4 leading-[1.6]">
        Based on overnight changes and your pipeline across all 11 locations,
        here are the 3 highest-leverage moves for today.
      </div>

      {activeStrategies.map((s) => (
        <StrategyCard
          key={s.id}
          strategy={s}
          onApprove={() => approve(s.id)}
          onLater={() => later(s.id)}
        />
      ))}

      {laterStrategies.length > 0 && (
        <>
          <SectionLabel>Deferred</SectionLabel>
          {laterStrategies.map((s) => (
            <div key={s.id} className="opacity-50 transition-opacity duration-500">
              <StrategyCard
                strategy={s}
                onApprove={() => approve(s.id)}
                onLater={() => {}}
                deferred
              />
            </div>
          ))}
        </>
      )}

      {approvedStrategies.length > 0 && (
        <>
          <SectionLabel>Approved</SectionLabel>
          {approvedStrategies.map((s) => (
            <Card
              key={s.id}
              className="border-accent/30"
            >
              <div className="flex items-center gap-3">
                <span className="text-accent text-lg">{"✓"}</span>
                <div>
                  <div className="text-[13px] font-semibold text-accent">
                    Approved &mdash; {s.impacts[1]?.value?.split("(")[0]?.trim() || "4"} tasks queued for execution
                  </div>
                  <div className="text-xs text-text3 mt-0.5">{s.title}</div>
                </div>
              </div>
            </Card>
          ))}
        </>
      )}

      {activeCount > 0 && (
        <Card
          className="mt-5 text-center border-accent relative overflow-hidden"
        >
          <div className="absolute top-0 left-0 right-0 h-0.5 bg-accent" />
          <div className="text-[13px] text-text2 mb-3.5">
            <strong className="text-text">
              {activeCount} {activeCount === 1 ? "strategy" : "strategies"}
            </strong>{" "}
            ready &middot; 6 agents on standby &middot; estimated{" "}
            <strong className="text-text">14 tasks</strong> across 11 locations
          </div>
          <button
            onClick={approveAll}
            className="bg-[#c4161c] text-white border-none text-[13px] font-bold py-3 px-8 rounded-lg cursor-pointer font-mono btn-hover"
          >
            {"▶"} Approve All &amp; Start Execution
          </button>
          <div className="font-mono text-[11px] text-text3 mt-2.5">
            Your workforce will execute throughout the day. Check back tonight
            for results.
          </div>
        </Card>
      )}
    </div>
  );
}

function StrategyCard({
  strategy,
  onApprove,
  onLater,
  deferred = false,
}: {
  strategy: Strategy;
  onApprove: () => void;
  onLater: () => void;
  deferred?: boolean;
}) {
  return (
    <Card>
      <div className="flex items-center gap-2 mb-2.5">
        <span className="font-mono text-[11px] font-bold text-accent bg-accent-dim border border-accent rounded-[5px] py-0.5 px-[7px]">
          {strategy.id}
        </span>
        {strategy.badges.map((b) => (
          <span
            key={b.label}
            className="font-mono text-[10px] font-semibold py-0.5 px-2 rounded inline-flex items-center gap-1"
            style={{ color: b.color, border: `1px solid ${b.color}` }}
          >
            {b.label}
          </span>
        ))}
      </div>
      <div className="text-[14px] font-semibold mb-1.5">{strategy.title}</div>
      <div className="text-[13px] text-text2 leading-[1.6] mb-3.5">
        {strategy.description}
      </div>
      <div className="flex gap-5 flex-wrap mb-3.5">
        {strategy.impacts.map((impact) => (
          <div key={impact.label}>
            <span className="font-mono text-[10px] text-text3 block">
              {impact.label}
            </span>
            <span
              className="font-mono text-xs font-semibold block"
              style={impact.color ? { color: impact.color } : undefined}
            >
              {impact.value}
            </span>
          </div>
        ))}
      </div>
      <div className="flex gap-2">
        <Btn variant="primary" onClick={onApprove}>
          {"✓"} Approve
        </Btn>
        <Btn>Modify</Btn>
        {!deferred && <Btn onClick={onLater}>Later</Btn>}
      </div>
    </Card>
  );
}
