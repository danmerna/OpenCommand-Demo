"use client";

import { useState, useCallback, useEffect, useRef } from "react";
import { Card, Btn, SectionLabel, Dot } from "./shared";

const LEVELS = [
  { level: "L0", label: "You Ask AI", model: "Frontier", desc: "Agent only responds when you initiate. Full human control." },
  { level: "L1", label: "AI Asks You", model: "Standard", desc: "Agent proactively suggests actions but waits for approval before executing." },
  { level: "L2", label: "AI Does, Tells", model: "Fast", desc: "Agent executes autonomously and reports back. You review after the fact." },
  { level: "L3", label: "Full Auto", model: "Economy", desc: "Agent operates independently with minimal reporting. Maximum efficiency." },
];

const SAFETY_LOG = [
  {
    icon: "\u25bc",
    iconBg: "rgba(245,158,11,.1)",
    iconBorder: "var(--color-warn)",
    title: "Auto-demoted L2 \u2192 L1",
    desc: "Repriced a 2024 Case IH 8250 at La Crosse to $12K below floor cost. User manually reverted.",
    date: "Jun 8",
  },
  {
    icon: "\u25b2",
    iconBg: "var(--color-accent-dim)",
    iconBorder: "var(--color-accent)",
    title: "Manually promoted L1 \u2192 L2 (trial)",
    desc: "Promoted after 12 consecutive approved tasks. Trial: 7 days.",
    date: "Jun 5",
  },
  {
    icon: "\u25b2",
    iconBg: "var(--color-accent-dim)",
    iconBorder: "var(--color-accent)",
    title: "Initial assignment: L1",
    desc: "CMO recommended L1 \u2014 listing modifications involve pricing decisions across multiple locations.",
    date: "Jun 2",
  },
];

const INITIAL_ACTIVITIES = [
  {
    dot: "var(--color-accent)",
    text: "Optimized listing copy for 2023 Case IH 8250 \u2014 CTR +2.4%",
    tier: "flash",
    cost: "$0.02",
    time: "2h ago",
  },
  {
    dot: "var(--color-accent)",
    text: "Repriced 2021 Case IH 7250 at Rochelle ($295K \u2192 $278K)",
    tier: "flash",
    cost: "$0.03",
    time: "5h ago",
  },
  {
    dot: "var(--color-warn)",
    text: "Draft: Upgrade 5 aged units to featured \u2014 awaiting approval",
    tier: "flash",
    cost: "$0.01",
    time: "6h ago",
  },
  {
    dot: "var(--color-accent)",
    text: "Weekly listing report: 14 listings, 3,240 views across 11 locations",
    tier: "flash",
    cost: "$0.04",
    time: "1d ago",
  },
  {
    dot: "var(--color-crit)",
    text: "Photo reorder on La Crosse 6140 \u2014 Sandhills session expired",
    tier: "flash",
    cost: "$0.01",
    time: "3d ago",
  },
];

const NEW_ACTIVITIES = [
  "Updated photo gallery for Harvard 7250 \u2014 hero image swap",
  "Analyzed competitor pricing at Birkey's \u2014 4 units tracked",
  "Generated market report for WI combine segment",
  "Refreshed SEO tags on 3 TractorHouse listings",
  "Drafted pre-harvest promo copy for Rochelle location",
  "Monitored 2 new TractorHouse inquiries \u2014 routed to sales",
  "Updated Iron Comps data for 5 aged units",
  "Generated weekly performance summary for CMO",
];

export default function AgentDetail() {
  const [activeLevel, setActiveLevel] = useState(1);
  const [showModal, setShowModal] = useState(false);
  const [pendingLevel, setPendingLevel] = useState<number | null>(null);
  const [showCelebration, setShowCelebration] = useState(false);
  const [activities, setActivities] = useState(INITIAL_ACTIVITIES);
  const activityIndexRef = useRef(0);

  // Auto-add activity every 15 seconds
  useEffect(() => {
    const interval = setInterval(() => {
      const newActivity = {
        dot: "var(--color-accent)",
        text: NEW_ACTIVITIES[activityIndexRef.current % NEW_ACTIVITIES.length],
        tier: "flash",
        cost: `$0.0${Math.floor(Math.random() * 5) + 1}`,
        time: "just now",
      };
      activityIndexRef.current++;
      setActivities((prev) => [newActivity, ...prev].slice(0, 10));
    }, 15000);
    return () => clearInterval(interval);
  }, []);

  const handleLevelClick = useCallback(
    (level: number) => {
      if (level === activeLevel) return;
      setPendingLevel(level);
      setShowModal(true);
    },
    [activeLevel]
  );

  const confirmLevelChange = useCallback(() => {
    if (pendingLevel !== null) {
      setActiveLevel(pendingLevel);
      setShowModal(false);
      setPendingLevel(null);
    }
  }, [pendingLevel]);

  const handlePromote = useCallback(() => {
    setActiveLevel(2);
    setShowCelebration(true);
    setTimeout(() => setShowCelebration(false), 2000);
  }, []);

  return (
    <div className="max-w-[800px] mx-auto px-6 py-7">
      {/* Celebration overlay */}
      {showCelebration && (
        <div className="fixed inset-0 z-[150] pointer-events-none flex items-center justify-center">
          <div
            className="text-6xl"
            style={{ animation: "celebPop 0.5s ease-out" }}
          >
            {"🎉"}
          </div>
          {Array.from({ length: 20 }).map((_, i) => (
            <div
              key={i}
              className="fixed w-2 h-2 rounded-sm"
              style={{
                left: `${Math.random() * 100}%`,
                top: -10,
                background: ["#10b981", "#3b82f6", "#f59e0b", "#a78bfa"][i % 4],
                animation: `confetti-fall ${1 + Math.random()}s ease-in ${Math.random() * 300}ms forwards`,
              }}
            />
          ))}
        </div>
      )}

      {/* Modal */}
      {showModal && pendingLevel !== null && (
        <div className="fixed inset-0 z-[200] flex items-center justify-center bg-black/60">
          <div className="bg-surface border border-border rounded-xl p-6 max-w-md w-full mx-4">
            <div className="font-mono text-sm font-semibold mb-3">
              Change Autonomy Level?
            </div>
            <div className="text-[13px] text-text2 mb-4 leading-[1.6]">
              Change <strong className="text-text">Listing Optimizer</strong>{" "}
              from{" "}
              <strong className="text-text">
                Level {activeLevel}
              </strong>{" "}
              to{" "}
              <strong className="text-accent">
                Level {pendingLevel}
              </strong>
              ?
            </div>
            <div className="bg-surface2 border border-border rounded-lg p-3 mb-4">
              <div className="text-xs text-text3 mb-1">
                {LEVELS[pendingLevel].level}: {LEVELS[pendingLevel].label}
              </div>
              <div className="text-[13px] text-text2">
                {LEVELS[pendingLevel].desc}
              </div>
              <div className="font-mono text-[10px] text-text3 mt-2">
                Model tier: {LEVELS[pendingLevel].model}
              </div>
            </div>
            <div className="flex gap-2 justify-end">
              <Btn onClick={() => setShowModal(false)}>Cancel</Btn>
              <Btn variant="primary" onClick={confirmLevelChange}>
                Confirm Change
              </Btn>
            </div>
          </div>
        </div>
      )}

      {/* Breadcrumb */}
      <div className="font-mono text-xs text-text3 mb-6">
        &gt;_ Open Command {"›"} CMO {"›"} Sub-Agents {"›"}{" "}
        <span className="text-text">Listing Optimizer</span>
      </div>

      {/* Agent header */}
      <Card topColor="var(--color-cmo)" className="mb-5">
        <div className="flex justify-between items-center mb-4">
          <div className="flex items-center gap-3.5">
            <div
              className="w-[46px] h-[46px] rounded-[10px] flex items-center justify-center font-mono text-sm font-bold"
              style={{
                background: "rgba(59,130,246,.1)",
                border: "1px solid var(--color-cmo)",
                color: "var(--color-cmo)",
              }}
            >
              LO
            </div>
            <div>
              <div className="text-lg font-semibold">Listing Optimizer</div>
              <div className="font-mono text-[11px] text-text3">
                CMO Department &middot; Manages TractorHouse listings across all
                locations
              </div>
            </div>
          </div>
          <span className="font-mono text-[11px] text-accent bg-accent-dim border border-accent rounded-md py-[5px] px-3 flex items-center gap-[5px]">
            <Dot color="var(--color-accent)" pulse />
            Active
          </span>
        </div>
        <div className="grid grid-cols-4 gap-4 text-center max-[600px]:grid-cols-2">
          <div>
            <span className="font-mono text-xl font-bold block">47</span>
            <span className="text-[11px] text-text3">Tasks completed</span>
          </div>
          <div>
            <span className="font-mono text-xl font-bold block text-accent">
              96%
            </span>
            <span className="text-[11px] text-text3">Approval rate</span>
          </div>
          <div>
            <span className="font-mono text-xl font-bold block">$3.80</span>
            <span className="text-[11px] text-text3">Avg cost/task</span>
          </div>
          <div>
            <span className="font-mono text-xl font-bold block">42 min</span>
            <span className="text-[11px] text-text3">Avg time saved</span>
          </div>
        </div>
      </Card>

      {/* Autonomy Level */}
      <SectionLabel>Autonomy Level</SectionLabel>
      <Card>
        <div className="flex justify-between mb-[18px]">
          <span className="font-mono text-[13px] font-semibold">
            Who initiates the interaction?
          </span>
          <span className="font-mono text-xs text-accent bg-accent-dim border border-accent rounded-md py-1 px-2.5">
            Current: Level {activeLevel}
          </span>
        </div>
        <div className="flex mb-4">
          {LEVELS.map((lvl, i) => (
            <button
              key={lvl.level}
              onClick={() => handleLevelClick(i)}
              className={`flex-1 py-3 px-2 text-center border border-border font-mono cursor-pointer transition-all duration-300 ${
                i === 0 ? "rounded-l-lg" : ""
              } ${i === LEVELS.length - 1 ? "rounded-r-lg" : ""} ${
                i === activeLevel
                  ? "bg-accent-dim border-accent text-accent font-bold"
                  : "bg-surface2 text-text3 hover:border-border-light hover:text-text2"
              }`}
            >
              <span className="text-sm font-bold block">{lvl.level}</span>
              <span className="text-[9px] block mt-0.5">{lvl.label}</span>
            </button>
          ))}
        </div>
        <div className="text-[13px] text-text2 bg-surface2 border border-border rounded-lg p-3">
          <strong className="text-text">{LEVELS[activeLevel].level}: {LEVELS[activeLevel].label}</strong>
          <span className="text-text3"> &mdash; {LEVELS[activeLevel].desc}</span>
          <div className="font-mono text-[10px] text-text3 mt-1">
            Model tier: {LEVELS[activeLevel].model}
          </div>
        </div>
      </Card>

      {/* Trust & Promotion */}
      <SectionLabel>Trust &amp; Promotion</SectionLabel>
      <Card className="border-accent relative overflow-hidden">
        <div className="absolute top-0 left-0 right-0 h-0.5 bg-accent" />
        <div className="flex justify-between mb-3.5">
          <span className="font-mono text-[13px] font-semibold text-accent">
            Promotion Eligible
          </span>
          <span className="font-mono text-[11px] text-accent bg-accent-dim rounded-md py-1 px-2.5">
            {"▲"} L1 {"→"} L2 recommended
          </span>
        </div>
        <div className="grid grid-cols-3 gap-4 text-center mb-3.5">
          <div>
            <span className="font-mono text-[22px] font-bold text-accent block">
              96%
            </span>
            <span className="text-[11px] text-text3">Approval rate</span>
          </div>
          <div>
            <span className="font-mono text-[22px] font-bold text-accent block">
              47
            </span>
            <span className="text-[11px] text-text3">Tasks completed</span>
          </div>
          <div>
            <span className="font-mono text-[22px] font-bold text-accent block">
              21d
            </span>
            <span className="text-[11px] text-text3">Days at L1</span>
          </div>
        </div>
        <div className="bg-accent-dim border border-accent rounded-lg px-4 py-3.5 flex items-center justify-between">
          <div className="text-[13px] text-text2 leading-[1.5]">
            <strong className="text-accent">Listing Optimizer</strong> completed
            47 tasks at 96% approval over 21 days. Promoting to{" "}
            <strong className="text-accent">Level 2</strong> means
            auto-optimizing listings across all 11 locations.
          </div>
          <Btn variant="primary" onClick={handlePromote} className="ml-3 whitespace-nowrap">
            Promote to L2
          </Btn>
        </div>
      </Card>

      {/* Safety Ratchet Log */}
      <SectionLabel>Safety Ratchet Log</SectionLabel>
      <Card>
        {SAFETY_LOG.map((log, i) => (
          <div
            key={i}
            className={`flex items-start gap-3 py-3 ${
              i < SAFETY_LOG.length - 1 ? "border-b border-border" : ""
            }`}
          >
            <div
              className="w-[26px] h-[26px] rounded-md flex items-center justify-center shrink-0 font-mono text-[11px] font-bold"
              style={{
                background: log.iconBg,
                border: `1px solid ${log.iconBorder}`,
                color: log.iconBorder,
              }}
            >
              {log.icon}
            </div>
            <div className="flex-1">
              <div className="text-[13px] font-medium">{log.title}</div>
              <div className="text-xs text-text3 leading-[1.5]">{log.desc}</div>
            </div>
            <span className="font-mono text-[10px] text-text3">{log.date}</span>
          </div>
        ))}
      </Card>

      {/* Recent Activity */}
      <SectionLabel>Recent Activity</SectionLabel>
      <Card>
        {activities.map((act, i) => (
          <div
            key={`${act.text}-${i}`}
            className={`flex items-center justify-between py-2.5 ${
              i < activities.length - 1 ? "border-b border-border" : ""
            }`}
            style={
              act.time === "just now"
                ? { animation: "slideDown 0.4s ease-out" }
                : undefined
            }
          >
            <div className="flex items-center gap-2.5 flex-1">
              <Dot color={act.dot} />
              <span className="text-[12.5px] text-text2">{act.text}</span>
            </div>
            <div className="flex gap-3.5 shrink-0">
              <span className="font-mono text-[9px] bg-surface3 rounded px-[7px] py-0.5 text-text3">
                {act.tier}
              </span>
              <span className="font-mono text-[11px] text-text3">
                {act.cost}
              </span>
              <span className="font-mono text-[10px] text-text3">
                {act.time}
              </span>
            </div>
          </div>
        ))}
      </Card>

      <style jsx>{`
        @keyframes slideDown {
          from {
            opacity: 0;
            transform: translateY(-12px);
          }
          to {
            opacity: 1;
            transform: translateY(0);
          }
        }
        @keyframes celebPop {
          0% {
            transform: scale(0);
            opacity: 0;
          }
          60% {
            transform: scale(1.3);
          }
          100% {
            transform: scale(1);
            opacity: 1;
          }
        }
      `}</style>
    </div>
  );
}
