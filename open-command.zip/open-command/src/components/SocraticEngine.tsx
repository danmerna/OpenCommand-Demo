"use client";

import { useState, useCallback, useEffect, useRef } from "react";
import { Card, Btn, SectionLabel, MetricRow, Dot } from "./shared";

const SOURCES = [
  {
    color: "var(--color-sf)",
    name: "Anvil Pro (Salesforce)",
    metrics: [
      { label: "Combine leads (active)", value: "42" },
      { label: "Combine quotes open", value: "11 · $4.2M" },
      { label: "Combines sold YTD", value: "9" },
      { label: "Avg combine deal size", value: "$342K" },
      { label: "Win rate (combines)", value: "18%" },
      { label: "Avg days to close", value: "71 days" },
    ],
  },
  {
    color: "var(--color-inv)",
    name: "Inventory (Anvil + Sandhills)",
    metrics: [
      { label: "Combines on lot", value: "16 (7 new, 9 used)" },
      { label: "Avg days on lot", value: "118 days" },
      { label: "Aged > 180 days", value: "5 units · $1.4M floor" },
      { label: "Floor plan interest", value: "$17,200/mo" },
      { label: "Headers in stock", value: "11 corn / 6 draper / 3 bean" },
      { label: "Trade-ins pending eval", value: "4 combines · $820K" },
    ],
  },
  {
    color: "var(--color-th)",
    name: "TractorHouse / WebStats",
    metrics: [
      { label: "Your combine listings", value: "14 (across 11 locations)" },
      { label: "Detail page views (30d)", value: "3,240" },
      { label: "Contact clicks", value: "22" },
      { label: "Your price vs market", value: "+6.1% above avg" },
      { label: "Featured listing spend", value: "$1,800/mo (5 units)" },
      { label: "Featured vs standard CTR", value: "3.9% vs 0.7%" },
      { label: "Competing dealers (75mi)", value: "8 Case IH dealers" },
      { label: "Market demand trend", value: "Combine searches +28% MoM" },
    ],
  },
  {
    color: "var(--color-gm)",
    name: "Gmail / SMS (Twilio)",
    metrics: [
      { label: "Combine inquiries (30d)", value: "26" },
      { label: "Avg response time", value: "4.8 hours" },
      { label: "Responded < 10 min", value: "5 of 26 (19%)" },
      { label: "No response", value: "6 inquiries" },
      { label: "Source: TractorHouse", value: "14 of 26 (54%)" },
      { label: "Past buyers (combine > 5yr)", value: "31 in CRM" },
    ],
  },
  {
    color: "var(--color-qb)",
    name: "QuickBooks Online",
    isFlat: true,
    flatMetrics: [
      { label: "Combine margin (new)", value: "5.9%" },
      { label: "Combine margin (used)", value: "17.2%" },
      { label: "Floor cost (YTD)", value: "$84K" },
      { label: "Parts/service attach", value: "68% of sales" },
      { label: "Avg service rev/unit", value: "$16,800/yr" },
    ],
  },
];

const INSIGHTS = [
  {
    type: "warn" as const,
    html: '<strong>Combine searches up 28% MoM</strong> — harvest buying season is starting across WI and northern IL. But your 14 listings across 11 locations are priced <strong>6.1% above market</strong> with 8 competing Case IH dealers within 75 miles.',
  },
  {
    type: "crit" as const,
    html: '<strong>6 combine inquiries got zero response</strong> and your avg is 4.8 hours across locations. On a $342K avg deal, each lost lead costs <span class="font-mono font-semibold" style="color:var(--color-crit)">~$62K</span> in expected revenue. Those 6 missed leads represent <span class="font-mono font-semibold" style="color:var(--color-crit)">~$369K in lost pipeline</span>.',
  },
  {
    type: "info" as const,
    html: '<strong>5 featured listings get 3.9% CTR vs 0.7% standard</strong> — 5.6x higher click-through. Your 5 aged units (180+ days) are all running standard. <strong>Featuring those 5 would cost ~$2,000/mo but could generate 8-12 additional leads</strong> — each worth ~$62K in pipeline.',
  },
  {
    type: "info" as const,
    html: '<strong>31 past buyers in your CRM own combines older than 5 years</strong> across all 11 locations. A coordinated "upgrade before harvest" campaign could <strong>generate 5-8 qualified trade-up conversations</strong>.',
  },
  {
    type: "good" as const,
    html: '<strong>Used combines earn 17.2% margin vs 5.9% new</strong>, plus 68% attach a service contract worth $16,800/yr. Used is <span class="font-mono font-semibold" style="color:var(--color-accent)">2.6x more profitable</span> per unit.',
  },
];

const QUESTIONS = [
  {
    num: 1,
    title: 'Your combines are <strong>priced 6.1% above market with 8 Case IH competitors within 75 miles</strong>.',
    detail: 'Should we reprice the 5 aged units (180+ days, $17.2K/month in floor plan) to match market and run them as "pre-harvest specials" on TractorHouse?',
    badges: [
      { label: "CMO", color: "var(--color-cmo)" },
      { label: "CFO", color: "var(--color-cfo)" },
    ],
    subtasks: [
      { task: "Pull current pricing for 5 aged units", agent: "Listing Optimizer", status: "ready" },
      { task: "Calculate market-match prices from Iron Comps", agent: "Pricing Agent", status: "ready" },
      { task: "Update TractorHouse listings with new prices", agent: "Listing Optimizer", status: "pending" },
      { task: "Create 'Pre-Harvest Special' badge templates", agent: "Content Agent", status: "pending" },
    ],
  },
  {
    num: 2,
    title: 'Your featured listings get <strong>5.6x higher click-through (3.9% vs 0.7%)</strong> but your 5 aged units are all standard.',
    detail: "Featuring them costs ~$2,000/mo but could generate 8-12 additional leads worth ~$62K each. Should we upgrade all 5 to featured immediately?",
    badges: [{ label: "CMO", color: "var(--color-cmo)" }],
    subtasks: [
      { task: "Identify 5 aged standard listings", agent: "Listing Optimizer", status: "ready" },
      { task: "Upgrade to featured on TractorHouse", agent: "Listing Optimizer", status: "pending" },
      { task: "Optimize listing photos and descriptions", agent: "Content Agent", status: "pending" },
    ],
  },
  {
    num: 3,
    title: 'You have <strong>31 past buyers with combines older than 5 years</strong> across all locations.',
    detail: "Should I draft a coordinated SMS campaign across all 11 locations offering trade-in valuations + first look at your 9 used units?",
    badges: [
      { label: "CMO", color: "var(--color-cmo)" },
      { label: "CEO", color: "var(--color-ceo)" },
    ],
    subtasks: [
      { task: "Pull list of 31 past combine buyers from CRM", agent: "Data Agent", status: "ready" },
      { task: "Draft SMS templates per location", agent: "Content Agent", status: "pending" },
      { task: "Set up Twilio campaign with location routing", agent: "Comms Agent", status: "pending" },
      { task: "Schedule sends for optimal engagement times", agent: "Comms Agent", status: "pending" },
    ],
  },
  {
    num: 4,
    title: '<strong>6 combine inquiries got zero response</strong> — that\'s ~$369K in lost pipeline.',
    detail: "Should we deploy instant SMS auto-replies for all TractorHouse and website combine inquiries across all locations?",
    badges: [
      { label: "CTO", color: "var(--color-cto)" },
      { label: "CMO", color: "var(--color-cmo)" },
    ],
    subtasks: [
      { task: "Configure Twilio auto-reply for TractorHouse leads", agent: "Comms Agent", status: "ready" },
      { task: "Set up location-based routing logic", agent: "Comms Agent", status: "pending" },
      { task: "Deploy Calendly integration for each location", agent: "CTO Agent", status: "pending" },
    ],
  },
  {
    num: 5,
    title: 'Used combines are <strong>2.6x more profitable than new</strong> ($62K vs $24K first-year value).',
    detail: "You have 4 trade-in evals pending worth $820K. Should we fast-track those appraisals and prioritize used combine sales?",
    badges: [
      { label: "CFO", color: "var(--color-cfo)" },
      { label: "CEO", color: "var(--color-ceo)" },
    ],
    subtasks: [
      { task: "Pull 4 pending trade-in evaluations from Anvil Pro", agent: "Data Agent", status: "ready" },
      { task: "Run Iron Comps market analysis for each unit", agent: "Pricing Agent", status: "pending" },
      { task: "Generate appraisal recommendations", agent: "Pricing Agent", status: "pending" },
    ],
  },
];

const SUGGESTED_PROMPTS = [
  "How do I move more combines before harvest?",
  "Which locations have the highest floor plan costs?",
  "What\u2019s our lead response time vs competitors?",
];

type Phase = "idle" | "assembling" | "sources" | "analyzing" | "insights" | "questions" | "done";

export default function SocraticEngine() {
  const [query, setQuery] = useState("");
  const [phase, setPhase] = useState<Phase>("done"); // Start with content shown
  const [visibleSources, setVisibleSources] = useState(SOURCES.length);
  const [visibleInsights, setVisibleInsights] = useState(INSIGHTS.length);
  const [visibleQuestions, setVisibleQuestions] = useState(QUESTIONS.length);
  const [expandedQuestions, setExpandedQuestions] = useState<Set<number>>(new Set());
  const [visibleSubtasks, setVisibleSubtasks] = useState<Record<number, number>>({});
  const timeoutsRef = useRef<NodeJS.Timeout[]>([]);

  const clearTimeouts = useCallback(() => {
    timeoutsRef.current.forEach(clearTimeout);
    timeoutsRef.current = [];
  }, []);

  const submit = useCallback(
    (q: string) => {
      if (!q.trim()) return;
      clearTimeouts();
      setQuery(q);
      setPhase("assembling");
      setVisibleSources(0);
      setVisibleInsights(0);
      setVisibleQuestions(0);
      setExpandedQuestions(new Set());
      setVisibleSubtasks({});

      const t1 = setTimeout(() => {
        setPhase("sources");
        SOURCES.forEach((_, i) => {
          const t = setTimeout(() => {
            setVisibleSources((prev) => prev + 1);
          }, i * 200);
          timeoutsRef.current.push(t);
        });
      }, 1200);
      timeoutsRef.current.push(t1);

      const t2 = setTimeout(() => {
        setPhase("analyzing");
      }, 1200 + SOURCES.length * 200 + 200);
      timeoutsRef.current.push(t2);

      const t3 = setTimeout(() => {
        setPhase("insights");
        INSIGHTS.forEach((_, i) => {
          const t = setTimeout(() => {
            setVisibleInsights((prev) => prev + 1);
          }, i * 200);
          timeoutsRef.current.push(t);
        });
      }, 1200 + SOURCES.length * 200 + 1200);
      timeoutsRef.current.push(t3);

      const t4 = setTimeout(() => {
        setPhase("questions");
        QUESTIONS.forEach((_, i) => {
          const t = setTimeout(() => {
            setVisibleQuestions((prev) => prev + 1);
          }, i * 150);
          timeoutsRef.current.push(t);
        });
      }, 1200 + SOURCES.length * 200 + 1200 + INSIGHTS.length * 200 + 200);
      timeoutsRef.current.push(t4);

      const t5 = setTimeout(() => {
        setPhase("done");
      }, 1200 + SOURCES.length * 200 + 1200 + INSIGHTS.length * 200 + 200 + QUESTIONS.length * 150 + 200);
      timeoutsRef.current.push(t5);
    },
    [clearTimeouts]
  );

  useEffect(() => {
    return () => clearTimeouts();
  }, [clearTimeouts]);

  const toggleExecute = useCallback((qNum: number) => {
    setExpandedQuestions((prev) => {
      const next = new Set(prev);
      if (next.has(qNum)) {
        next.delete(qNum);
        return next;
      }
      next.add(qNum);
      // Animate subtasks appearing
      const q = QUESTIONS.find((q) => q.num === qNum);
      if (q) {
        q.subtasks.forEach((_, i) => {
          setTimeout(() => {
            setVisibleSubtasks((prev) => ({
              ...prev,
              [qNum]: (prev[qNum] || 0) + 1,
            }));
          }, i * 150);
        });
      }
      return next;
    });
  }, []);

  const insightBorders: Record<string, string> = {
    warn: "var(--color-warn)",
    crit: "var(--color-crit)",
    info: "var(--color-info)",
    good: "var(--color-accent)",
  };
  const insightBgs: Record<string, string> = {
    warn: "linear-gradient(90deg,var(--color-warn-dim),transparent 40%)",
    crit: "linear-gradient(90deg,var(--color-crit-dim),transparent 40%)",
    info: "linear-gradient(90deg,var(--color-info-dim),transparent 40%)",
    good: "linear-gradient(90deg,var(--color-accent-dim),transparent 40%)",
  };

  return (
    <div className="max-w-[1120px] mx-auto px-6 py-7">
      {/* Input bar */}
      <div className="mb-5">
        <div className="flex gap-3 mb-3">
          <input
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && submit(query)}
            placeholder="Ask a question about your business..."
            className="flex-1 bg-surface border border-border rounded-lg px-4 py-3 text-sm text-text font-sans outline-none focus:border-accent transition-colors"
          />
          <Btn variant="primary" onClick={() => submit(query)} className="px-6">
            Ask
          </Btn>
        </div>
        <div className="flex gap-2 flex-wrap">
          {SUGGESTED_PROMPTS.map((p) => (
            <button
              key={p}
              onClick={() => {
                setQuery(p);
                submit(p);
              }}
              className="font-mono text-[10px] text-text3 bg-surface2 border border-border rounded-md px-3 py-1.5 cursor-pointer hover:border-border-light hover:text-text2 transition-all"
            >
              {p}
            </button>
          ))}
        </div>
      </div>

      {phase !== "idle" && (
        <>
          {/* Status indicator */}
          <div className="flex items-center gap-4 mb-5">
            <span className="font-mono text-xs font-medium text-accent bg-accent-dim border border-accent rounded-md py-1 px-3 flex items-center gap-1.5">
              <Dot color="var(--color-accent)" pulse />5 sources &middot; 4.8s
            </span>
            <span className="text-[15px] font-semibold">
              Combine sales acceleration
            </span>
          </div>

          {/* User request card */}
          <Card className="mb-6">
            <div className="font-mono text-[10px] font-semibold uppercase tracking-[0.1em] text-text3 mb-2">
              User Request
            </div>
            <div className="text-[19px] font-semibold tracking-[-0.02em]">
              &ldquo;{query || "How do I move more combines before harvest season?"}&rdquo;
            </div>
          </Card>

          {/* Assembling indicator */}
          {phase === "assembling" && (
            <div className="flex items-center gap-3 py-4">
              <div className="flex gap-1">
                <span className="w-1.5 h-1.5 rounded-full bg-accent dot-pulse" />
                <span className="w-1.5 h-1.5 rounded-full bg-accent dot-pulse" style={{ animationDelay: "0.3s" }} />
                <span className="w-1.5 h-1.5 rounded-full bg-accent dot-pulse" style={{ animationDelay: "0.6s" }} />
              </div>
              <span className="font-mono text-xs text-text3">
                Assembling context...
              </span>
            </div>
          )}

          {/* Sources */}
          {(phase === "sources" || phase === "analyzing" || phase === "insights" || phase === "questions" || phase === "done") && (
            <>
              <SectionLabel>Live Data Pulled</SectionLabel>
              {SOURCES.slice(0, visibleSources).map((src, i) => (
                <div
                  key={i}
                  className="transition-all duration-300"
                  style={{
                    animation: "slideUp 0.3s ease-out",
                  }}
                >
                  <Card topColor={src.color} className="mb-2.5">
                    <div className="flex items-center gap-2 mb-3">
                      <Dot color={src.color} />
                      <span className="font-mono text-xs font-semibold">
                        {src.name}
                      </span>
                    </div>
                    {src.isFlat ? (
                      <div className="flex gap-7 flex-wrap">
                        {src.flatMetrics?.map((m) => (
                          <div key={m.label}>
                            <span className="text-[11px] text-text3 block">
                              {m.label}
                            </span>
                            <span className="font-mono text-[13px] font-semibold">
                              {m.value}
                            </span>
                          </div>
                        ))}
                      </div>
                    ) : (
                      src.metrics?.map((m) => (
                        <MetricRow
                          key={m.label}
                          label={m.label}
                          value={m.value}
                        />
                      ))
                    )}
                  </Card>
                </div>
              ))}
            </>
          )}

          {/* Analyzing indicator */}
          {phase === "analyzing" && (
            <div className="flex items-center gap-3 py-4">
              <div className="flex gap-1">
                <span className="w-1.5 h-1.5 rounded-full bg-accent dot-pulse" />
                <span className="w-1.5 h-1.5 rounded-full bg-accent dot-pulse" style={{ animationDelay: "0.3s" }} />
                <span className="w-1.5 h-1.5 rounded-full bg-accent dot-pulse" style={{ animationDelay: "0.6s" }} />
              </div>
              <span className="font-mono text-xs text-text3">
                Analyzing cross-source patterns...
              </span>
            </div>
          )}

          {/* Insights */}
          {(phase === "insights" || phase === "questions" || phase === "done") && (
            <>
              <SectionLabel>Cross-Source Insights</SectionLabel>
              {INSIGHTS.slice(0, visibleInsights).map((insight, i) => (
                <div
                  key={i}
                  className="border border-border rounded-lg px-[18px] py-3.5 mb-2 text-[13.5px] leading-[1.65] text-text2"
                  style={{
                    borderLeftWidth: 3,
                    borderLeftColor: insightBorders[insight.type],
                    background: insightBgs[insight.type],
                    animation: "slideUp 0.3s ease-out",
                  }}
                  dangerouslySetInnerHTML={{ __html: insight.html }}
                />
              ))}
            </>
          )}

          {/* Questions */}
          {(phase === "questions" || phase === "done") && visibleQuestions > 0 && (
            <Card
              className="mt-7 !px-6 !py-6 relative overflow-hidden"
              topColor="linear-gradient(90deg,var(--color-accent),var(--color-sf),var(--color-th),var(--color-qb))"
            >
              <div className="absolute top-0 left-0 right-0 h-0.5" style={{ background: "linear-gradient(90deg,var(--color-accent),var(--color-sf),var(--color-th),var(--color-qb))" }} />
              <div className="flex items-center gap-2.5 mb-1.5">
                <span className="font-mono text-accent font-bold text-sm">
                  &gt;_
                </span>
                <span className="font-mono text-[13px] font-semibold">
                  OPEN COMMAND
                </span>
                <span className="font-mono text-[11px] text-text3">
                  &middot; Socratic intent engine &middot; 5 tools &middot; 5
                  insights
                </span>
              </div>
              <div className="text-[13px] text-text2 mb-5">
                You have 16 combines across 11 locations, $4.2M in open quotes,
                and harvest buying ramping up 28%. Here&apos;s where the leverage is:
              </div>

              {QUESTIONS.slice(0, visibleQuestions).map((q) => (
                <div
                  key={q.num}
                  className="py-4 border-b border-border last:border-b-0"
                  style={{ animation: "slideUp 0.3s ease-out" }}
                >
                  <div className="flex items-start">
                    <span className="font-mono text-xs font-bold text-accent bg-accent-dim border border-accent rounded-md w-6 h-6 inline-flex items-center justify-center shrink-0 mr-2.5">
                      {q.num}
                    </span>
                    <span
                      className="text-sm font-semibold leading-[1.5]"
                      dangerouslySetInnerHTML={{ __html: q.title }}
                    />
                  </div>
                  <div className="text-[13px] text-text2 leading-[1.65] mt-2 mb-3 ml-[34px]">
                    {q.detail}
                  </div>
                  <div className="flex items-center gap-2 ml-[34px] flex-wrap">
                    <Btn
                      variant="primary"
                      onClick={() => toggleExecute(q.num)}
                    >
                      {expandedQuestions.has(q.num) ? "▼ Collapse" : "▶ Execute"}
                    </Btn>
                    <Btn>Skip</Btn>
                    {q.badges.map((b) => (
                      <span
                        key={b.label}
                        className="font-mono text-[10px] font-semibold py-0.5 px-2 rounded"
                        style={{
                          color: b.color,
                          border: `1px solid ${b.color}`,
                        }}
                      >
                        {b.label}
                      </span>
                    ))}
                  </div>

                  {/* Subtask decomposition */}
                  {expandedQuestions.has(q.num) && (
                    <div className="ml-[34px] mt-3 border-l-2 border-accent/30 pl-4">
                      {q.subtasks
                        .slice(0, visibleSubtasks[q.num] || 0)
                        .map((st, si) => (
                          <div
                            key={si}
                            className="flex items-center justify-between py-2 text-xs"
                            style={{ animation: "slideUp 0.2s ease-out" }}
                          >
                            <div className="flex items-center gap-2">
                              <Dot
                                color={
                                  st.status === "ready"
                                    ? "var(--color-accent)"
                                    : "var(--color-text3)"
                                }
                              />
                              <span className="text-text2">{st.task}</span>
                            </div>
                            <div className="flex items-center gap-2 shrink-0">
                              <span className="font-mono text-[9px] bg-surface3 rounded px-[7px] py-0.5 text-text3">
                                {st.agent}
                              </span>
                              <span
                                className="font-mono text-[9px] font-semibold px-1.5 py-0.5 rounded"
                                style={{
                                  color:
                                    st.status === "ready"
                                      ? "var(--color-accent)"
                                      : "var(--color-text3)",
                                  background:
                                    st.status === "ready"
                                      ? "var(--color-accent-dim)"
                                      : "var(--color-surface2)",
                                }}
                              >
                                {st.status}
                              </span>
                            </div>
                          </div>
                        ))}
                    </div>
                  )}
                </div>
              ))}
            </Card>
          )}
        </>
      )}

      <style jsx>{`
        @keyframes slideUp {
          from {
            opacity: 0;
            transform: translateY(12px);
          }
          to {
            opacity: 1;
            transform: translateY(0);
          }
        }
      `}</style>
    </div>
  );
}
