import { ReactNode } from "react";

export function Card({
  children,
  className = "",
  topColor,
  style,
}: {
  children: ReactNode;
  className?: string;
  topColor?: string;
  style?: React.CSSProperties;
}) {
  return (
    <div
      className={`bg-surface border border-border rounded-[10px] px-5 py-[18px] relative overflow-hidden mb-2.5 ${className}`}
      style={style}
    >
      {topColor && (
        <div
          className="absolute top-0 left-0 right-0 h-0.5"
          style={{ background: topColor }}
        />
      )}
      {children}
    </div>
  );
}

export function Badge({
  children,
  color,
  className = "",
}: {
  children: ReactNode;
  color: string;
  className?: string;
}) {
  return (
    <span
      className={`font-mono text-[10px] font-semibold py-0.5 px-2 rounded inline-flex items-center gap-1 ${className}`}
      style={{ color, border: `1px solid ${color}` }}
    >
      {children}
    </span>
  );
}

export function Dot({
  color,
  pulse = false,
  className = "",
}: {
  color: string;
  pulse?: boolean;
  className?: string;
}) {
  return (
    <span
      className={`w-[7px] h-[7px] rounded-full inline-block shrink-0 ${
        pulse ? "dot-pulse" : ""
      } ${className}`}
      style={{ background: color }}
    />
  );
}

export function Btn({
  children,
  variant = "default",
  onClick,
  className = "",
  disabled = false,
}: {
  children: ReactNode;
  variant?: "default" | "primary" | "red";
  onClick?: () => void;
  className?: string;
  disabled?: boolean;
}) {
  const base =
    "font-mono text-[11px] font-semibold py-[7px] px-3.5 rounded-md cursor-pointer transition-all duration-150 btn-hover";
  const variants = {
    default:
      "border border-border bg-transparent text-text3 hover:border-border-light hover:text-text2",
    primary: "bg-accent text-black border-none hover:bg-[#34d399]",
    red: "bg-[#c4161c] text-white border-none text-[13px] font-bold py-3 px-8 rounded-lg",
  };

  return (
    <button
      onClick={onClick}
      disabled={disabled}
      className={`${base} ${variants[variant]} ${
        disabled ? "opacity-50 cursor-not-allowed" : ""
      } ${className}`}
    >
      {children}
    </button>
  );
}

export function SectionLabel({ children }: { children: ReactNode }) {
  return (
    <div className="font-mono text-[10px] font-semibold uppercase tracking-[0.12em] text-text3 mt-6 mb-3.5">
      {children}
    </div>
  );
}

export function MetricRow({
  label,
  value,
  valueColor,
}: {
  label: string;
  value: string;
  valueColor?: string;
}) {
  return (
    <div className="flex justify-between items-baseline text-[13px] py-0.5">
      <span className="text-text2">{label}</span>
      <span
        className="font-mono text-xs font-medium text-right"
        style={valueColor ? { color: valueColor } : undefined}
      >
        {value}
      </span>
    </div>
  );
}

export function SourcePill({ children }: { children: ReactNode }) {
  return (
    <span className="font-mono text-[9px] bg-surface3 rounded px-[7px] py-0.5 text-text3 inline-block m-0.5">
      {children}
    </span>
  );
}
