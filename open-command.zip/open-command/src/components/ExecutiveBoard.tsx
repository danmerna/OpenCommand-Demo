"use client";

import { useState, useCallback, useEffect, useRef } from "react";
import { Card, Btn, SectionLabel, Dot } from "./shared";

const EXECS = [
  {
    role: "CEO",
    title: "Chief Executive Officer",
    subtitle: "Strategic position & multi-location coordination",
    color: "var(--color-ceo)",
    bgColor: "rgba(245,158,11,.1)",
    pills: ["Anvil Pro", "All Locations", "Market Data"],
    response:
      'Yes — but use it to strengthen the Johnson Tractor brand across the region. With 11 locations, you have a competitive advantage no single-location dealer can match: regional coverage. Frame it as "Pre-Harvest Ready — certified, inspected, and available at any Johnson Tractor location."',
    verdict: {
      label: "Recommendation",
      text: "Unified campaign with consistent pricing, messaging, and delivery-ready certification across all 11 stores.",
    },
    metric: { label: "Confidence", value: "High — seasonal + regional advantage" },
  },
  {
    role: "CMO",
    title: "Chief Marketing Officer",
    subtitle: "Demand generation across locations",
    color: "var(--color-cmo)",
    bgColor: "rgba(59,130,246,.1)",
    pills: ["WebStats", "TractorHouse", "Gmail"],
    response:
      "Run the campaign on TractorHouse but stagger by location to avoid self-cannibalization. Group by geography: WI stores target WI/MN buyers, IL stores target IL/IN buyers. Feature all 5 aged units and add email blasts from each location's contact list.",
    verdict: {
      label: "Recommendation",
      text: "Geo-targeted campaign: WI and IL stores run parallel but non-overlapping TractorHouse promotions.",
    },
    metric: { label: "Expected leads", value: "8-12 additional from featuring" },
  },
  {
    role: "CTO",
    title: "Chief Technology Officer",
    subtitle: "Systems & cross-location operations",
    color: "var(--color-cto)",
    bgColor: "rgba(167,139,250,.1)",
    pills: ["Gmail/Twilio", "Anvil Pro"],
    response:
      "Fix the response gap first. Your 6 missed inquiries came from 4 different locations. Deploy a single Twilio auto-reply number that routes to the nearest location, with shared Calendly for walkaround scheduling.",
    verdict: {
      label: "Recommendation",
      text: "Single response system across all 11 locations. Deploy before the campaign goes live.",
    },
    metric: { label: "Current leak rate", value: "23% of leads unresponded" },
  },
  {
    role: "CFO",
    title: "Chief Financial Officer",
    subtitle: "Margin analysis & capital efficiency",
    color: "var(--color-cfo)",
    bgColor: "rgba(16,185,129,.1)",
    pills: ["QuickBooks", "Anvil Pro", "Iron Comps"],
    response:
      "Reprice aggressively on used, conservatively on new. Used margin at 17.2% gives you room — even at market-match you'd clear 12%+ margin. New units at 5.9% are tight; don't go below 4%.",
    verdict: {
      label: "Recommendation",
      text: "Used: reprice to market. New: reprice to market-2% max. Flag units near curtailment for priority.",
    },
    metric: { label: "Floor plan saved", value: "$17,200/mo if aged units sell" },
  },
];

const CONSENSUS_VOTES = [
  { role: "CEO", color: "var(--color-ceo)", vote: "Approve" },
  { role: "CMO", color: "var(--color-cmo)", vote: "Approve" },
  { role: "CTO", color: "var(--color-cto)", vote: "Approve (prereq)" },
  { role: "CFO", color: "var(--color-cfo)", vote: "Approve (floor)" },
];

type Phase = "idle" | "thinking" | "streaming" | "consensus" | "done";

export default function ExecutiveBoard() {
  const [question, setQuestion] = useState("");
  const [phase, setPhase] = useState<Phase>("done");
  const [streamedText, setStreamedText] = useState<Record<number, string>>({});
  const [visibleVotes, setVisibleVotes] = useState(CONSENSUS_VOTES.length);
  const [showConsensus, setShowConsensus] = useState(true);
  const animRef = useRef<number[]>([]);

  const speeds = [3, 4, 5, 6]; // chars per tick — CEO fastest, CFO slowest

  const clearAnims = useCallback(() => {
    animRef.current.forEach(clearInterval);
    animRef.current = [];
  }, []);

  const submit = useCallback(
    (q: string) => {
      if (!q.trim()) return;
      clearAnims();
      setQuestion(q);
      setPhase("thinking");
      setStreamedText({});
      setVisibleVotes(0);
      setShowConsensus(false);

      // After 1.5s of "thinking", start streaming
      setTimeout(() => {
        setPhase("streaming");

        EXECS.forEach((exec, i) => {
          let charIndex = 0;
          const interval = setInterval(() => {
            charIndex += speeds[i];
            if (charIndex >= exec.response.length) {
              charIndex = exec.response.length;
              clearInterval(interval);
            }
            setStreamedText((prev) => ({
              ...prev,
              [i]: exec.response.substring(0, charIndex),
            }));
          }, 30);
          animRef.current.push(interval as unknown as number);
        });

        // After all done streaming (~3s), show consensus
        const maxTime = Math.max(
          ...EXECS.map((e, i) => (e.response.length / speeds[i]) * 30)
        );
        setTimeout(() => {
          setPhase("consensus");
          setShowConsensus(true);
          CONSENSUS_VOTES.forEach((_, i) => {
            setTimeout(() => {
              setVisibleVotes((prev) => prev + 1);
            }, i * 200);
          });
          setTimeout(() => setPhase("done"), CONSENSUS_VOTES.length * 200 + 200);
        }, maxTime + 500);
      }, 1500);
    },
    [clearAnims]
  );

  useEffect(() => {
    return () => clearAnims();
  }, [clearAnims]);

  const isStreaming = phase === "streaming" || phase === "thinking";

  return (
    <div className="max-w-[1120px] mx-auto px-6 py-7">
      {/* Input */}
      <div className="flex gap-3 mb-6">
        <input
          type="text"
          value={question}
          onChange={(e) => setQuestion(e.target.value)}
          onKeyDown={(e) => e.key === "Enter" && submit(question)}
          placeholder="Ask your executive board a strategic question..."
          className="flex-1 bg-surface border border-border rounded-lg px-4 py-3 text-sm text-text font-sans outline-none focus:border-accent transition-colors"
        />
        <Btn variant="primary" onClick={() => submit(question)} className="px-6">
          Ask Board
        </Btn>
      </div>

      {phase !== "idle" && (
        <>
          {/* Board question */}
          <Card className="mb-6">
            <div className="font-mono text-[10px] font-semibold uppercase tracking-[0.1em] text-text3 mb-2">
              Board Question
            </div>
            <div className="text-[17px] font-semibold tracking-[-0.02em]">
              &ldquo;{question || "Should we run a coordinated pre-harvest pricing campaign across all 11 locations?"}&rdquo;
            </div>
            <div className="flex gap-4 mt-2.5">
              <span className="font-mono text-[11px] text-text3">
                4 executives responding
              </span>
              <span className="font-mono text-[11px] text-text3">
                Context: CTX-2026-0891
              </span>
            </div>
          </Card>

          {/* Executive grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
            {EXECS.map((exec, i) => {
              const text = phase === "done" || phase === "consensus"
                ? exec.response
                : streamedText[i] || "";
              const isComplete = text.length >= exec.response.length;
              const showThinking = phase === "thinking";

              return (
                <Card key={exec.role} topColor={exec.color}>
                  <div className="flex items-center gap-2.5 mb-1">
                    <div
                      className="w-[34px] h-[34px] rounded-lg flex items-center justify-center font-mono text-xs font-bold shrink-0"
                      style={{
                        background: exec.bgColor,
                        border: `1px solid ${exec.color}`,
                        color: exec.color,
                      }}
                    >
                      {exec.role}
                    </div>
                    <div>
                      <div className="font-mono text-xs font-semibold">
                        {exec.title}
                      </div>
                      <div className="text-[11px] text-text3">
                        {exec.subtitle}
                      </div>
                    </div>
                  </div>

                  <div className="mt-2 mb-3 flex flex-wrap">
                    {exec.pills.map((p) => (
                      <span
                        key={p}
                        className="font-mono text-[9px] bg-surface3 rounded px-[7px] py-0.5 text-text3 inline-block m-0.5"
                      >
                        {p}
                      </span>
                    ))}
                  </div>

                  <div className="text-[12.5px] leading-[1.7] text-text2 mb-3.5 min-h-[60px]">
                    {showThinking ? (
                      <div className="flex gap-1 py-2">
                        <span className="w-1.5 h-1.5 rounded-full bg-text3 dot-pulse" />
                        <span className="w-1.5 h-1.5 rounded-full bg-text3 dot-pulse" style={{ animationDelay: "0.3s" }} />
                        <span className="w-1.5 h-1.5 rounded-full bg-text3 dot-pulse" style={{ animationDelay: "0.6s" }} />
                      </div>
                    ) : (
                      <>
                        <strong>{text.split(".")[0]}.</strong>
                        {text.substring(text.indexOf(".") + 1)}
                        {!isComplete && (
                          <span className="inline-block w-0.5 h-3.5 bg-text2 ml-0.5 dot-pulse" />
                        )}
                      </>
                    )}
                  </div>

                  {isComplete && (
                    <>
                      <div className="bg-surface2 border border-border rounded-lg px-3 py-2.5 my-3 mb-2.5">
                        <div
                          className="font-mono text-[10px] font-semibold uppercase tracking-[0.1em] mb-1"
                          style={{ color: exec.color }}
                        >
                          {exec.verdict.label}
                        </div>
                        <div className="text-[12.5px] font-medium leading-[1.5]">
                          {exec.verdict.text}
                        </div>
                      </div>
                      <div className="flex justify-between items-baseline text-[11.5px]">
                        <span className="text-text3">
                          {exec.metric.label}
                        </span>
                        <span className="font-mono text-[10.5px] text-text2">
                          {exec.metric.value}
                        </span>
                      </div>
                    </>
                  )}
                </Card>
              );
            })}
          </div>

          {/* Consensus */}
          {showConsensus && (
            <Card
              className="mt-4 border-accent relative overflow-hidden"
              style={{ animation: "slideUp 0.4s ease-out" }}
            >
              <div className="absolute top-0 left-0 right-0 h-0.5 bg-accent" />
              <div className="flex items-center gap-2.5 mb-3">
                <span className="text-base">{"⚡"}</span>
                <span className="font-mono text-[13px] font-semibold">
                  Board Consensus
                </span>
              </div>
              <div className="text-[13.5px] leading-[1.7] text-text2 mb-3.5">
                <strong className="text-text">
                  All four recommend the campaign, with conditions:
                </strong>{" "}
                Fix lead response first (CTO), stagger by geography (CMO),
                maintain floor on new margins at 4% (CFO), brand as regional
                strength (CEO).
              </div>
              <div className="flex gap-2.5 flex-wrap mb-4">
                {CONSENSUS_VOTES.slice(0, visibleVotes).map((v) => (
                  <span
                    key={v.role}
                    className="font-mono text-[11px] py-[5px] px-2.5 rounded-md border border-accent text-accent bg-accent-dim flex items-center gap-1.5"
                    style={{ animation: "slideUp 0.3s ease-out" }}
                  >
                    <Dot color={v.color} />
                    {v.role} &mdash; {v.vote}
                  </span>
                ))}
              </div>
              <div className="flex gap-2">
                <Btn variant="primary">{"▶"} Approve &amp; Execute All</Btn>
                <Btn>Discuss Further</Btn>
              </div>
            </Card>
          )}
        </>
      )}

      <style jsx>{`
        @keyframes slideUp {
          from {
            opacity: 0;
            transform: translateY(12px);
          }
          to {
            opacity: 1;
            transform: translateY(0);
          }
        }
      `}</style>
    </div>
  );
}
