# Open Command — AI Business Intelligence Dashboard

A dark terminal-aesthetic dashboard for an AI-powered business intelligence product. Built as a clickable demo for **Johnson Tractor**, a multi-location agricultural equipment dealer.

## Quick Start

```bash
npm install
npm run dev
# Open http://localhost:3000
```

## Tech Stack

- **Next.js 16** (App Router, TypeScript)
- **Tailwind CSS v4** (custom theme in `globals.css` via `@theme` block)
- **Fonts**: JetBrains Mono (monospace UI elements), DM Sans (body text)
- No external animation libraries — all animations use CSS keyframes + `setTimeout`/`setInterval`

## Design System

All colors are defined as CSS custom properties in `src/app/globals.css`:

| Token | Value | Usage |
|-------|-------|-------|
| `--color-bg` | `#08090a` | Page background |
| `--color-surface` | `#0f1012` | Card backgrounds |
| `--color-border` | `#25262a` | Card/section borders |
| `--color-text` | `#f4f4f5` | Primary text |
| `--color-text2` | `#9ca3af` | Secondary text |
| `--color-text3` | `#6b7280` | Muted text / labels |
| `--color-accent` | `#10b981` | Green accent (primary actions) |
| `--color-ceo` | `#f59e0b` | CEO executive color (amber) |
| `--color-cmo` | `#3b82f6` | CMO executive color (blue) |
| `--color-cto` | `#a78bfa` | CTO executive color (purple) |
| `--color-cfo` | `#10b981` | CFO executive color (green) |

## Architecture

```
src/
  app/
    layout.tsx          # Root layout with fonts, OG meta tags, scanline overlay
    page.tsx            # Main page — tab state, view transitions, keyboard shortcuts
    globals.css         # Tailwind theme, keyframes, utility classes
  components/
    shared.tsx          # Reusable primitives: Card, Badge, Dot, Btn, SectionLabel, MetricRow, SourcePill
    TopBar.tsx          # Sticky nav with logo + tab buttons
    MorningBriefing.tsx # View 1: Overnight alerts + strategy cards with approve/defer/later
    SocraticEngine.tsx  # View 2: Search bar + progressive data source reveal + insights + questions
    ExecutiveBoard.tsx  # View 3: 4 exec cards with simultaneous streaming + consensus
    AgentDetail.tsx     # View 4: Agent stats, autonomy dial, promotion, safety log, live activity
    CommandPalette.tsx  # Cmd+K overlay for quick navigation
```

## The 4 Views

### 1. Morning Briefing (`MorningBriefing.tsx`)
- Default view. Shows "Good morning, Taylor." greeting
- 4 overnight alert cards (color-coded: red/yellow/blue/green)
- 3 strategy cards, each with Approve / Modify / Later buttons
- **Approve**: card collapses into "Approved" section with green checkmark
- **Later**: card fades to 50% opacity, moves to "Deferred" section
- **Approve All**: staggered approval animation (200ms between each), confetti burst when all 3 done
- Bottom CTA: red "Approve All & Start Execution" button
- State tracked via `Record<number, 'active' | 'approved' | 'later'>`

### 2. Socratic Engine (`SocraticEngine.tsx`)
- Search bar with 3 suggested prompts
- On submit, progressive loading sequence:
  1. "Assembling context..." (1.2s with pulsing dots)
  2. 5 data source cards slide up one-by-one (200ms stagger)
  3. "Analyzing cross-source patterns..." (1.2s)
  4. 5 insight cards reveal one-by-one (200ms stagger, color-coded borders: warn/crit/info/good)
  5. 5 Socratic question cards appear (150ms stagger)
- Each question has an "Execute" button that expands to show subtask decomposition (agent name + status badges, animated 150ms stagger)
- Phase state machine: `idle -> assembling -> sources -> analyzing -> insights -> questions -> done`

### 3. Executive Board (`ExecutiveBoard.tsx`)
- Search bar for strategic questions
- On submit:
  1. All 4 exec cards show typing indicator (3 pulsing dots) for 1.5s
  2. All 4 stream responses simultaneously, character-by-character at different speeds (CEO=3 chars/tick fastest, CFO=6 chars/tick slowest, 30ms interval)
  3. After all finish, verdict boxes appear with recommendations
  4. Consensus bar slides up from below with vote badges appearing one-by-one (200ms stagger)
- Each exec card has: avatar, title, source pills, response text, verdict box, bottom metric
- Consensus shows 4 vote badges + "Approve & Execute All" button

### 4. Agent Detail (`AgentDetail.tsx`)
- Breadcrumb: `>_ Open Command > CMO > Sub-Agents > Listing Optimizer`
- Agent header card with 4 stats (tasks completed, approval rate, avg cost, avg time saved)
- **Autonomy Dial**: 4 segments (L0-L3), clicking a different level opens confirmation modal with level description + model tier
- **Trust & Promotion**: shows 96%/47/21d stats, "Promote to L2" button triggers celebration animation (confetti + emoji pop)
- **Safety Ratchet Log**: 3 entries showing demotions/promotions with dates
- **Recent Activity**: live-updating feed, new item added every 15 seconds with slide-down animation, capped at 10 items

## Global Features

### Page Transitions (`page.tsx`)
- Tab switching: outgoing view fades/slides out, incoming fades/slides in from opposite direction
- Direction-aware: moving right = slide left-to-right, moving left = slide right-to-left
- 200ms exit + 250ms enter

### Keyboard Shortcuts (`CommandPalette.tsx` + `page.tsx`)
- `1` / `2` / `3` / `4` — switch tabs (only when not focused on an input)
- `a` — approve all strategies (Morning Briefing)
- `Cmd+K` / `Ctrl+K` — open command palette
- Command palette: arrow keys to navigate, Enter to select, Escape to close

### Visual Effects (`globals.css`)
- **Scanline overlay**: faint horizontal lines scrolling slowly over entire page (`scanline-overlay` class on body)
- **Dot pulse**: 2s infinite opacity animation for status indicators
- **Confetti**: particles fall from top with rotation, used on approve-all and agent promotion
- **Glow**: green accent `box-shadow` on interactive elements
- **Button hover**: `translateY(-1px)` + subtle glow on hover

## Data

All data is hardcoded — no API calls. The demo uses realistic Johnson Tractor data:
- 11 locations across WI and IL
- Case IH combine inventory ($196K-$312K units)
- Competitors: Birkey's Farm Store, 8 Case IH dealers within 75 miles
- CRM: Anvil Pro (Salesforce), listings: TractorHouse/Sandhills, financials: QuickBooks
- Comms: Gmail + Twilio SMS

## Deployment

```bash
npm run build   # Static export, no server needed
```

Deploy to Vercel, Netlify, or any static host. No environment variables required.
